using System;

namespace ProjectBackendDevelopment.Config
{
    public class ConnectionStrings
    {
        public string SQL { get; set; }
    }
}
